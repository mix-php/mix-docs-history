## `MasterSlave` 组件

PdoCluster 是 Pdo 的集群版本，当数据库需要主从配置时使用，使用方法与 Pdo 完全一至，仅配置不同。

|  类  |  调用  | 运行环境  |
| --- | --- | --- |
|  mix\rdb\PdoCluster  |  \Mix::app()->rdb | ALL |

## 组件配置

App配置文件中，该组件的默认配置如下：

~~~
// 数据库
'rdb'      => [
    // 类路径
    'class'                           => 'mix\rdb\PdoCluster',
    // 主服务器组
    'masters'                         => [
        'mysql:host=192.168.1.11;port=3306;charset=utf8;dbname=test',
        'mysql:host=192.168.1.12;port=3306;charset=utf8;dbname=test',
    ],
    // 配置主服务器
    'masterConfig'                    => [
        // 数据库用户名
        'username' => 'root',
        // 数据库密码
        'password' => '',
    ],
    // 从服务器组
    'slaves'                          => [
        'mysql:host=192.168.1.75;port=3306;charset=utf8;dbname=test',
        'mysql:host=192.168.1.76;port=3306;charset=utf8;dbname=test',
        'mysql:host=192.168.1.77;port=3306;charset=utf8;dbname=test',
        'mysql:host=192.168.1.78;port=3306;charset=utf8;dbname=test',
    ],
    // 配置从服务器
    'slaveConfig'                     => [
        // 数据库用户名
        'username' => 'root',
        // 数据库密码
        'password' => '',
    ],
    // 设置PDO属性: http://php.net/manual/zh/pdo.setattribute.php
    'attribute'                       => [
        // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
    ],
],
~~~