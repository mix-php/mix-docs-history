## Apache/PHP-FPM 部署

MixPHP 也可以部署在 Apache/PHP-FPM 之下, 该种方式不需要 Swoole 扩展，可以部署在 Windows 系统，特别适合开发阶段使用，有些个人用户使用的服务器无法定制环境，也可以使用该方式部署。

>[info] Apache/PHP-FPM 部署使用的配置文件为 main_traditional.php 。

### 1. 修改应用配置 

在 Apache/PHP-FPM 中部署需要修改应用配置，按下表修改相关组件的Class路径。

>[success] 在初始代码的 main_compatible.php 文件中，我们已经帮你做了这些，你可以直接跳过这一步。

|  组件名  |  mix-httpd 部署  |  Apache/PHP-FPM 部署  |
| --- | --- | --- |
| request |  mix\http\Request  |  mix\http\compatible\Request  |
| response |  mix\http\Response  |  mix\http\compatible\Response  |

### 2. 配置Apache/Nginx的Root目录

将你的Apache/Nginx的配置文件中的root目录指向：

~~~shell
// Apache
DocumentRoot /mixphp/apps/模块目录/public

// Nginx
root /mixphp/apps/模块目录/public;
~~~

## 3. URL重写

框架的路由是 `PATHINFO` 实现的，需要通过URL重写去掉URL中的 `index.php`。

### [ Apache ]

1. httpd.conf 配置文件中加载了mod_rewrite.so 模块
2. AllowOverride None 将 None 改为 All

### [ Nginx + PHP-FPM ]

在 nginx.conf 中配置转发规则

~~~shell
server {
    server_name www.test.com;
    listen 80;
    root /data/mixphp/apps/index/public/;
    index index.php index.html index.htm;

    location / {
        if (!-e $request_filename) {
            rewrite ^/(.*)$ /index.php/$1 last;
        }
    }

    location ~ ^(.+\.php)(.*)$ {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_split_path_info ^(.+\.php)(.*)$;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        include fastcgi_params;
    }
}
~~~


