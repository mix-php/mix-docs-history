## Application 类

MixPHP 里 Application 类是每个应用的核心，也是组件的容器，下面简称为 App 类。

|  类  |  调用  |
| --- | --- |
|  mix\console\Application  |  app() |
|  mix\http\Application  |  app() |

## 开发中 App 对象有什么用

框架中所有系统类库都注册在 App 对象里，开发中到处都要使用到它。

## 如何使用

下面的语句就能获取到 App 对象，在框架内任何地方都可以使用。

~~~php
// 原始调用
\Mix::app()

// 助手调用
app()
~~~

获取 GET 参数

~~~php
$get = app()->request->get();
~~~

建立一个 session 变量

~~~php
app()->session->set('userName', '小明');
~~~

## 获取 App 路径信息

>[info] 所有路径末尾都包含"/"

获取应用目录路径

~~~php
app()->basePath
~~~

获取运行目录路径

~~~php
app()->getRuntimePath()
~~~

>[info] 以下两个方法在 mix\console\Application 中没有。
 
获取公开目录路径

~~~php
app()->getPublicPath()
~~~

获取视图目录路径

~~~php
app()->getViewPath()
~~~