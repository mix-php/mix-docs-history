>[danger] 该服务依赖 Swoole 扩展，Windows下无法执行。

## HTTP 服务器

mix-httpd 是官方使用 MixPHP 开发的 HTTP 服务器，用于执行 "Web应用"，基于 Swoole 扩展的 `swoole_http_server`，拥有比 Apache/PHP-FPM 更高的性能。

>[info] mix-httpd 其实就是一个使用 MixPHP 开发的一个命令行应用程序。

## 位置

mix-httpd 在框架的 `apps/httpd` 目录。

## 配置文件

mix-httpd 的配置文件路径为：

~~~shell
apps/httpd/config/main.php
~~~

只需要配置文件内的 `server` 字段内的参数即可，如下：

### `host` 参数

设置服务器绑定的主机。

### `port` 参数

设置服务器绑定的端口。

### `setting` 参数

正式环境需设置合适的运行参数，与性能相关，非常重要。     
全部参数列表：https://wiki.swoole.com/wiki/page/274.html

### `virtualHosts` 参数

该参数设定你需要在服务器中运行的Web应用，设置方式如下：

>[info] mix-httpd 支持同时运行多个Web应用，这是其他基于 Swoole 的框架所不具备的。

~~~
// 虚拟主机：运行在 Server 内的 Web 应用
'virtualHosts' => [
    // 默认主机
    '*'                        => __DIR__ . '/../../../apps/index/config/main_httpd.php',
    // 单个主机
    'www.a.com'                => __DIR__ . '/../../../apps/index/config/main_httpd.php',
    // 单个主机 (带端口)
    'www.a.com:8080'           => __DIR__ . '/../../../apps/index/config/main_httpd.php',
    // 多个主机
    'www.a.com:8080|www.b.com' => __DIR__ . '/../../../apps/index/config/main_httpd.php',
],
~~~

## 命令管理

mix-httpd 集成了一些命令，让用户能很方便的操作服务器。

>[info] 请使用 root 账号启动 mix-httpd。

全部命令如下：

- service start : 启动服务器。
- service stop : 停止服务器。
- service restart : 重启服务器。
- service reload : 重启所有工作进程，用于刷新代码。

`service start` 命令有两个很好用的参数：

- -d : 后台运行 (为了方便错误调试，不建议在开发阶段使用该参数)。
- -u : 代码热更新 (开发阶段使用)，需关闭 PHP 的 OPcache，该参数会使 worker 进程只处理一次请求就销毁，所以不要在生产环境中使用。

在命令行使用以下命令管理：

~~~shell
// 查看帮助
mix-httpd -h

// 启动
mix-httpd service start

// 启动（守护）
mix-httpd service start -d

// 启动（守护 + 热更新）
mix-httpd service start -d -u

// 停止
mix-httpd service stop

// 重启
mix-httpd service restart

// 重启工作进程
mix-httpd service reload

// 状态
mix-httpd service status
~~~

