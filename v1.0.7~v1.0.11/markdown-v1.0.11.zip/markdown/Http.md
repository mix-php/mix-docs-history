## `Http` 类

如今的后端开发中，服务器之间的交互越来越多，而交互大多采用的是 Http 的对接方式，所以 MixPHP 封装了一个 Http 类来处理这些需求。

|  类  |  调用  |
| --- | --- |
|  mix\client\Http  |  new Http([配置]);  |

## 如何使用

GET 请求：

~~~
$http = new \mix\client\Http([
    'timeout' => 10
]);
$http->get('http://www.baidu.com');
if ($http->getStatusCode() == 200) {
    $response = $http->getBody();
} else {
    $response = $http->getError();
}
~~~

POST 请求：

~~~
$http = new \mix\client\Http([
    'timeout' => 10,
    'headers' => [
        'access_token' => 'ACCESS_TOKEN',
    ],
]);
$http->post('https://api.weixin.qq.com/cgi-bin/user/info/updateremark?access_token=ACCESS_TOKEN', ['username' => '18600001111']);
if ($http->getStatusCode() == 200) {
    $response = $http->getBody();
} else {
    $response = $http->getError();
}
~~~