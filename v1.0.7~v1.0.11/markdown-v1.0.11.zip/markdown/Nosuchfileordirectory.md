## No such file or directory

执行 `bin` 目录的入口文件，或者 `install.sh` 时，抛出以下错误：

~~~shell
[root@localhost bin]# ./mix-httpd 
: No such file or directory
~~~

原因：这是因为代码下载到 windows 后，文件回车换行默认为：`CRLF` ，而 Liunx 的 Shell 执行文件只能是 `LF`。

解决：使用编辑器将文件修改为 `LF` 再上传即可。
