## `PDOPersistent` 组件

PDOPersistent 是 PDO 的长连接版本，使用方法与 PDO 完全一至，仅配置不同。

>[success] 长连接比短连接可提升两倍左右的并发性能。

|  类  |  调用  | 连接方式 | 
| --- | --- | --- |
|  mix\client\PDOPersistent  |  app()->rdb | 长连接 |

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\RDB  | RDB:: |

## 长连接超时问题

MySQL 配置文件内的 `interactive_timeout` 与 `wait_timeout` 参数，决定了 sleep 多长时间的连接会被主动 kill，正常情况下是需要用户自己来处理连接超时的问题，但使用 `PDOPersistent` 组件，用户不需要处理，组件底层已经帮你处理了。

## 组件配置

比 `PDO` 多了以下配置项：

* reusableConnection：重用相同配置的连接，当使用 mix-httpd 开发的 Web 应用中有多个 host 时，该配置可减少连接数量。

App配置文件中，该组件的默认配置如下：

~~~
// 数据库
'rdb'      => [
    // 类路径
    'class'                           => 'mix\client\PdoPersistent',
    // 数据源格式
    'dsn'                             => 'mysql:host=127.0.0.1;port=3306;charset=utf8;dbname=test',
    // 数据库用户名
    'username'                        => 'root',
    // 数据库密码
    'password'                        => '',
    // 设置PDO属性: http://php.net/manual/zh/pdo.setattribute.php
    'attribute'                       => [
        // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
    ],
    // 重用连接(相同配置)
    'reusableConnection'                => true,
],
~~~