## `Redis` 组件

Redis 组件是使用魔术方法对 redis 扩展提供的方法做映射处理，可调用扩展内提供的所有方法。

|  类  |  调用  | 连接方式 | 
| --- | --- | --- |
|  mix\client\Redis  | app()->redis | 短连接 |

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\Redis  | Redis:: |

## 组件配置

App配置文件中，该组件的默认配置如下：

~~~
// redis
'redis'    => [
    // 类路径
    'class'        => 'mix\client\Redis',
    // 主机
    'host'         => '127.0.0.1',
    // 端口
    'port'         => 6379,
    // 密码
    'password'     => '',
    // 数据库
    'database'     => 0,
],
~~~

## 如何使用

这里只举例几个常用方法，更多方法请自行百度。

~~~
// 写入一个string值
Redis::set($key, $value);

// 写入一个带生存时间的string值
Redis::setex($key, 3600, $value);

// 在名称为key的list左边（头）添加一个值为value的 元素
Redis::lpush($key, $value);
~~~