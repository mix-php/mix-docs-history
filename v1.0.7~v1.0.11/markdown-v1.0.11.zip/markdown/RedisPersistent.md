## `RedisPersistent` 组件

RedisPersistent 是 Redis 的长连接版本，使用方法与 Redis 完全一至，MixHttpd 中单个工作进程不管运行多少个 host，都共用一个连接，另外你不需要处理连接超时的问题，组件底层已经帮你处理了。

>[success] 长连接比短连接可提升两倍左右的并发性能。

|  类  |  调用  | 连接方式 | 
| --- | --- | --- |
|  mix\client\RedisPersistent  | app()->redis | 长连接 |

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\Redis  | Redis:: |

## 长连接超时问题

Redis 配置文件内的 `timeout` 参数，决定了 sleep 多长时间的连接会被主动 kill，正常情况下是需要用户自己来处理连接超时的问题，但使用 `RedisPersistent` 组件，用户不需要处理，组件底层已经帮你处理了。

## 组件配置

比 `Redis` 多了以下配置项：

* reusableConnection：重用相同配置的连接，当使用 mix-httpd 开发的 Web 应用中有多个 host 时，该配置可减少连接数量。

App配置文件中，该组件的默认配置如下：

~~~
// redis
'redis'    => [
    // 类路径
    'class'        => 'mix\client\RedisPersistent',
    // 主机
    'host'         => '127.0.0.1',
    // 端口
    'port'         => 6379,
    // 密码
    'password'     => '',
    // 数据库
    'database'     => 0,
    // 重用连接(相同配置)
    'reusableConnection' => true,
],
~~~