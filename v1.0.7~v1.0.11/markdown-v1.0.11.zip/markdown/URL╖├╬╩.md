## URL路由原理

MixPHP 是通过 `$_SERVER['PATH_INFO']` 实现的URL路由，所以你可以这样访问。

~~~shell
http://localhost/index.php/news/article
~~~
    
开启URL重写隐藏入口文件后，可以这样访问。

~~~shell
http://localhost/news/article
~~~
    
## 默认的URL路由规则

MixPHP 默认只支持以下这种，URL分段无法带参数，如有需求，需要配置路由规则。

>[info] http://localhost/控制器/操作

### 默认不支持以下传参方式

ThinkPHP

>[info] http://localhost/模块/控制器/操作/[参数名1/参数值1]/[参数名2/参数值2]

CodeIgniter

>[info] http://localhost/控制器/操作/[参数1]/[参数2]

