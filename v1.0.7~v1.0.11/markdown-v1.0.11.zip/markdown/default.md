<br>

<p style="text-align: center;"><img src="https://box.kancloud.cn/90f9b3c1d667aefa77b09ea1b7ffb054_120x120.png" alt=""></p>

<h3 style="text-align: center;"> 高性能 • 轻量级 • 命令行 </h3>

<h3 style="text-align: center;">『 基于 Swoole 的常驻内存型 PHP 高性能框架 』</h3>

<br>

## 核心特征

* 高性能：极简架构 + Swoole引擎，超过 Phalcon 这类 C 扩展框架的性能；
* 服务器：框架自带 mix-httpd 替代 Apache/PHP-FPM 作为高性能 HTTP 服务器；
* 组件：基于组件的框架结构，并集成了大量开箱即用的组件；
* 自动加载：遵循 PSR-4，使用 Composer 构建；
* 模块化：支持 Composer ，可以很方便的使用第三方库；
* 中间件：注册方便，更友好的对请求进行过滤和处理；
* 门面：核心组件全部内置门面类，助力快速开发；
* 路由：底层全正则实现，性能高，配置简单；
* 验证器：集成了使用简单但功能强大的验证器，支持多场景控制；
* 视图：使用 PHP 做模板引擎，支持布局、属性；
* 长连接：按进程保持的长连接，支持 Mysql/Redis；
* 命令行：封装了命令行开发基础设施，可快速开发定时任务、守护进程；
* 多进程：简易的多进程开发方式，充分利用多核性能，可处理大量数据；
* WebSocket：具备长连接开发能力，扩展了 PHP 开发领域；

## GitHub

>[success]	支持的用户请加个Star吧，让更多人发现MixPHP。

https://github.com/mixstart/mixphp

## 官网

http://mixphp.cn

## 技术交流

作者微博：http://weibo.com/onanying ，关注最新进展     
官方QQ群：284806582，敲门暗号：phper

## License

GNU General Public License, version 2 see https://www.gnu.org/licenses/gpl-2.0.html
