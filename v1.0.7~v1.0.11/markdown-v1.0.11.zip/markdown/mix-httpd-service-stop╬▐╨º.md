## mix-httpd service stop 无效

当出现以下情况：刚启动 mix-httpd，service stop 时就提示没有在运行。

~~~shell
[www@localhost bin]# mix-httpd service start -d
                           _____
_______ ___ _____ ___ _____  / /_  ____
__/ __ `__ \/ /\ \/ / / __ \/ __ \/ __ \
_/ / / / / / / /\ \/ / /_/ / / / / /_/ /
/_/ /_/ /_/_/ /_/\_\/ .___/_/ /_/ .___/
                   /_/         /_/

[2018-03-09 11:28:24] Server    Name: mix-httpd
[2018-03-09 11:28:24] PHP    Version: 5.6.34
[2018-03-09 11:28:24] Swoole Version: 1.9.21
[2018-03-09 11:28:24] Listen    Addr: 127.0.0.1
[2018-03-09 11:28:24] Listen    Port: 9501

[www@localhost bin]# /mix-httpd service stop
mix-httpd is not running.
~~~

## 原因

mix-httpd 的 stop 原理是通过 pid 文件，pid 文件保存在：

~~~
/var/run/mix-httpd.pid
~~~

因为非 root 账号无该文件夹的写权限，导致 pid 文件无法生成，使 mix-httpd 无法得知自己的执行状态。

## 解决方法

- 请使用 sudo mix-httpd service start -d 启动。
- 切换到 root 账号后启动。