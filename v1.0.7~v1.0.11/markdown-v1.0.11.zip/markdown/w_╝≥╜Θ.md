## HTTP 服务

本章内容是 MixPHP 的 Web 应用开发，MixPHP 底层对 Swoole 关于 Web 开发方面做了大量兼容性处理，让用户可以像使用传统 MVC 框架一样使用 Swoole 开发高性能 Web，降低了使用门槛。

|  类  |  调用  | 
| --- | --- | --- |
|  mix\http\Application  |  app() | 

## 应用场景

### WebSite

- 网站开发。
- 后台管理开发。

### WebAPI

- http接口开发。


