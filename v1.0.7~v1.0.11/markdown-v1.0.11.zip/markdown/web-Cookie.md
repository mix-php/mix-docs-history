## `Cookie` 组件

Cookie是储存在用户本地终端上的数据，该类用来操作这些数据。

|  类  |  调用  |
| --- | --- |
|  mix\http\Cookie  |  app()->cookie |

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\Cookie  | Cookie:: |

## 组件配置

App配置文件中，该组件的默认配置如下：

~~~
// Cookie
'cookie'   => [
    // 类路径
    'class'    => 'mix\http\Cookie',
    // 过期时间
    'expire'   => 31536000,
    // 有效的服务器路径
    'path'     => '/',
    // 有效域名/子域名
    'domain'   => '',
    // 仅通过安全的 HTTPS 连接传给客户端
    'secure'   => false,
    // 仅可通过 HTTP 协议访问
    'httponly' => false,
],
~~~

## `get` 方法

获取变量的值。

>[info] name不存在时返回null。

~~~
Cookie::get('name');
~~~

## `set` 方法

变量赋值。

~~~
Cookie::set('name', '小华');
~~~

## `has` 方法

判断变量是否存在。

~~~
Cookie::has('name');
~~~

## `delete` 方法

删除变量。

~~~
Cookie::delete('name');
~~~

## `clear` 方法

清空全部变量。

~~~
Cookie::clear();
~~~
