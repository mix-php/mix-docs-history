## `Session` 组件

Session（会话）组件可以让你保持一个用户的 "状态" ，并跟踪他在浏览你的网站时的活动。

|  类  |  调用  | 
| --- | --- | --- |
|  mix\http\Session  |  

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\Session  | Session:: |

>[danger] Session 组件暂时只支持 Redis，使用前需先安装 Redis 数据库。

## 组件配置

App配置文件中，该组件的默认配置如下：

~~~
// Session
'session' => [
    // 类路径
    'class'   => 'mix\http\Session',
    // 保存处理者
    'saveHandler' => [
        // 类路径
        'class'    => 'mix\client\Redis',
        // 主机
        'host'     => '127.0.0.1',
        // 端口
        'port'     => 6379,
        // 数据库
        'database' => 0,
        // 密码
        'password' => '',
    ],
    // 保存的Key前缀
    'saveKeyPrefix'  => 'MIXSSID:',
    // 生存时间
    'expires' => 7200,
    // session名
    'name'    => 'MIXSSID',
],
~~~

## 使用范例

用户登陆控制器：

~~~
// 登陆方法
public function actionLogin()
{
    /* 验证账号密码成功后 */
    // 保存会话信息
    $userinfo = [
        'uid'      => 1088,
        'openid'   => 'yZmFiZDc5MjIzZDMz',
        'username' => '小明',
    ];
    Session::set('userinfo', $userinfo);
    // 响应
    return $this->render('login', ['message' => '新增成功']);
}
~~~

效验Session：

在前置中间件中校验。

~~~
// 前置中间件的 handle 方法
public function handle($callable, \Closure $next)
{
    // 添加中间件执行代码
    $userinfo = Session::get('userinfo');
    if (empty($userinfo)) {
    	// 跳转到首页
    	return Response::redirect('/');
    }
    // 执行下一个中间件
    return $next();
}
~~~

## `set` 方法

变量赋值。

~~~
Session::set('name', '小华');
~~~

## `get` 方法

获取变量的值。

~~~
Session::get('name');
~~~

>[info] name不存在时返回null。

## `has` 方法

判断变量是否存在。

~~~
Session::has('name');
~~~

## `delete` 方法

删除变量。

~~~
Session::delete('name');
~~~

## `clear` 方法

清空全部变量。

~~~
Session::clear();
~~~

## `getSessionId` 方法

获取SessionId。

~~~
Session::getSessionId();
~~~