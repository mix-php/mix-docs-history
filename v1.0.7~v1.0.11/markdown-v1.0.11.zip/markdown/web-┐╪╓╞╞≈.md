## 控制器

控制器是应用程序中处理用户交互的部分，通常控制器负责读取请求数据，与模型交换数据，渲染视图并发送数据。

|  类  | 
| --- | 
|  mix\http\Controller  | 

## 一个简单的控制器

新建一个文件 IndexController.php ， 然后放入以下代码:

~~~
<?php

namespace apps\index\controllers;

use mix\http\Controller;

class IndexController extends Controller
{

    public function actionIndex()
    {
    	return 'Hello World!';
    }

}
~~~

## 命名空间与文件位置的关系

控制器定义的命名空间为：

~~~
namespace apps\index\controller;
~~~

因为根命名空间 `apps` 在 `composer.json` 内定义的路径为：

~~~
"apps\\": "apps/"
~~~

所以控制器的完整路径为：

~~~
apps/index/controller/IndexController.php
~~~

## URL访问控制器

MixPHP 默认定义了首页与一级目录的默认路由规则，所以上面的控制器可以这样访问：

~~~
http://site.com/index/index
~~~

第一段 `index` 指向 `IndexController` 类
第二段 `index` 指向 `actionIndex` 方法

## 首页控制器

首页控制器就是当URL中没有指定控制器名称时默认访问的控制器，`IndexController` 为MixPHP的首页控制器。

当访问下面的URL时：

~~~
http://site.com
~~~

默认访问:

~~~
apps/index/controller/IndexController.php
~~~

## 默认方法

默认方法就是当URL中没有指定方法名称时默认访问的方法，`actionIndex` 为MixPHP的默认方法。

当访问下面的URL时：

~~~
http://site.com/index
~~~

默认访问：

~~~
apps/index/controller/IndexController::actionIndex
~~~