>[danger] 该组件为系统组件，在组件树中只可命名为 request ，不可修改为其他名称。

## 请求

请求组件用来获取所有HTTP请求参数。

|  类  |  调用  | 运行环境  |
| --- | --- | --- |
|  mix\http\Request  |  app()->request | mix-httpd |
|  mix\http\compatible\Request  |  app()->request | Apache/PHP-FPM |

|  门面类  |  调用  |
| --- | --- |
|  mix\facades\Request  | Request:: |

## 组件配置

App配置文件中，该组件的默认配置如下：

>[info] 由于该类没有使用到其他参数，所以只有一个class字段。

~~~
// 请求
'request'  => [
    // 类路径
    'class' => 'mix\http\Request',
],
~~~

## 获取参数

|  方法  |  描述  |
| --- | --- |
|  route  |  获取路由参数  |
|  get  |  获取 $_GET 参数  |
|  post  |  获取 $_POST 参数  |
|  files  |  获取 $_FILES 参数  |
|  server  |  获取 $_SERVER 参数 (全部小写) |
|  header  |  获取 HEADER 参数 (全部小写) |
|  getRawBody  |  返回原始的 HTTP 包体 |

>[success] 以上所有方法变量名不存在时返回 null。

## 请求类型

|  方法  |  描述  |
| --- | --- |
|  method  | 返回请求类型 |
|  isGet  | 是否为 GET 请求 |
|  isPost  | 是否为 POST 请求 |
|  isPut	  | 是否为 PUT 请求 |
|  isPatch  | 是否为 PATCH 请求 |
|  isDelete  | 是否为 DELETE 请求 |
|  isHead  | 是否为 HEAD 请求 |
|  isOptions  | 是否为 OPTIONS 请求 |

## 请求路径

|  方法  |  描述  |
| --- | --- |
|  root  | 返回请求的域名 |
|  path  | 返回请求的路径 |
|  url  | 返回请求的URL |
|  fullUrl  | 返回请求的完整URL |

## 获取路由参数

~~~
// 获取单个参数
Request::route('name');

// 获取所有参数，返回数组
Request::route();
~~~

## 获取 `GET` 参数

~~~
// 获取单个参数
Request::get('name');

// 获取所有参数，返回数组
Request::get();
~~~

## 获取 `POST` 参数

~~~
// 获取单个参数
Request::post('name');

// 获取所有参数，返回数组
Request::post();
~~~

## 获取 `FILES` 参数

~~~
// 获取单个参数
Request::files('name');

// 获取所有参数，返回数组
Request::files();
~~~

## 获取 `SERVER` 参数

~~~
// 获取单个参数
Request::server('name');

// 获取所有参数，返回数组
Request::server();
~~~

## 获取 `HEADER ` 参数

~~~
// 获取单个参数
Request::header('name');

// 获取所有参数，返回数组
Request::header();
~~~

## 返回原始的 `HTTP` 包体

~~~
Request::getRawBody();
~~~

## 返回请求路径

~~~
Request::root(); // http//www.domain.com
Request::path(); // index/index.html
Request::url(); // http//www.domain.com/index/index.html
Request::fullUrl(); // http//www.domain.com/index/index.html?s=hello
~~~