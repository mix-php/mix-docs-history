## 视图

简单来说，一个视图其实就是一个 Web 页面，或者页面的一部分，像页头、页脚、侧边栏等，MixPHP的视图支持布局。

|  类  | 
| --- | 
|  mix\http\View  | 

## 创建一个视图

下面演示为控制器 `ProfileController` 创建一个视图，控制器代码如下：

~~~
<?php

namespace apps\index\controllers;

use mix\http\Controller;

class ProfileController extends Controller
{

    public $layout = 'main';

    public function actionIndex()
    {
        $data = [
            'name'    => '小明',
            'age'     => 18,
            'friends' => ['小红', '小花', '小飞'],
        ];
        return $this->render('index', $data);
    }

}
~~~

先在 `view/layout` 目录建立一个布局文件 `main.php`，代码如下：

~~~
<html>
<head>
    <title><?= $this->title ?></title>
</head>
<body>
    <?= $content ?>
</body>
</html>
~~~

然后在 `view` 目录创建一个 `profile` 目录，在目录中创建一个 `index.php` 文件，代码如下:

- MixPHP 的视图直接使用 PHP 做为引擎。
- 视图文件名全部使用小写，多个单词时，使用下划线分隔，例如：`setting_profile.php`。
- 通过 `$this->name` 可以传递数据到布局文件中使用。

~~~
<?php
$this->title = 'Profile';
?>

<p>name: <?= $name ?>, age: <?= $age ?></p>
<p>friends:</p>
<ul>
    <?php foreach($friends as $name): ?>
        <li><?= $name ?></li>
    <?php endforeach; ?>
</ul>
~~~

## 渲染视图

从上面的例子中可看出，视图的渲染是在控制器中，代码如下：

>[info] return $this->render(视图名, 数组);

### 视图名

不需要加上目录，框架会自动获取，只需输入视图文件名称，不需要带 `.php` 后缀。

### 数组

需要传递给视图使用的数据，是一个数组类型，数组 `key` 会变为视图内的变量名称，数组 `value` 会变为变量的值。

## 视图布局

当使用 `$this->render` 渲染视图时，MixPHP会获取控制器属性 `layout` 的值，用来读取对应的布局文件。

>[info] 如果控制器未定义该属性，则该属性默认为 main。

~~~
public $layout = 'main';
~~~

### 不使用布局

当有需求不需要使用到布局时，使用下面的代码渲染视图：

>[info] return $this->renderPartial(视图文件名, 数组);


## 视图嵌套

当你在布局中使用公共的侧边栏等类似的需求时，需要在视图中加载另一个视图，如下：

~~~
<?= $this->render('子视图名', $__data__); ?>
~~~

>[info] `$__data__` 为当前视图传入所有变量的数组，可以让子视图使用父视图的全部变量。