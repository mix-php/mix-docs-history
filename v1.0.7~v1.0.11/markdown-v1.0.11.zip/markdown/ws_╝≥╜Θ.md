>[danger] - 该服务依赖 Swoole 扩展，Windows下无法执行。
> - 异步 redis 需按 Swoole 官方要求安装 hiredis 与 重新编译 swoole，详情：https://wiki.swoole.com/wiki/page/p-redis.html 。

## WebSocket 服务

MixPHP 封装了非常完整的 WebSocket 解决方案，开箱即用，还在源代码中附带了完整范例代码。

|  类  |  调用  |  
| --- | --- | 
|  mix\websocket\WebSocketServer  |  app()->createObject('name') | 

## 使用场景

如： 消息推送、在线聊天、直播弹幕、棋牌游戏等。
 
## 优点
 
 - 能与 Session / Token 无缝对接，实现会话机制；
 - 可异步对接 Redis 的订阅，实现通过消息队列主动发消息至客户端，这样做出来的 WebSocket 服务可以做负载均衡，实现高性能；
 - 可通过消息处理器进行命令路由，实现传统MC分离的开发方式；
 - 模型验证器可在 WebSocket 的模型中使用，验证数据的有效性与合法性，远离脏数据、攻击的风险；

## 开发目录

~~~
├── apps                                             	应用目录
│   └── websocketd                                      WebSocket模块
│       ├── command                                     Console应用控制器目录
│       ├── config                                      配置目录
│       ├── library                                     类库目录
│       ├── model                                       表单模型目录
│       └── runtime                                     运行目录 (不可更改)
~~~

## 命令执行

~~~
mix-websocketd [入口文件] [命令] [选项]
~~~
 
## 范例

### 配置文件

[>> 到 GitHub 查看 DEMO <<](https://github.com/mixstart/mixphp/blob/master/apps/websocketd/config/main.php)

### 控制器代码

 源代码的范例里几乎把全部流程都写了，就差业务代码了。
 
[>> 到 GitHub 查看 DEMO  <<](https://github.com/mixstart/mixphp/blob/master/apps/websocketd/commands/ServiceCommand.php)

### 进程管理

在命令行使用以下命令管理。

~~~shell
// 查看帮助
mix-websocketd -h

// 启动
mix-websocketd service start

// 启动（守护）
mix-websocketd service start -d

// 停止
mix-websocketd service stop

// 重启
mix-websocketd service restart

// 状态
mix-websocketd service status
~~~

也可使用如下 Linux 命令管理进程。

~~~shell
// 查找进程
ps -ef | grep mix-websocketd

// 结束主进程
kill <PID>
~~~
